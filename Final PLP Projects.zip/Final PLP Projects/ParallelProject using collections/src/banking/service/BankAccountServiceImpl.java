package banking.service;

import java.util.ArrayList;
import java.util.List;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.dao.BankAccountDaoImpl;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public class BankAccountServiceImpl implements BankAccountService {
	static BankAccountDaoImpl dao = new BankAccountDaoImpl();
	static List<BankAccount> list = new ArrayList<BankAccount>();

	@Override
	public void CreateAccount(BankAccount bankaccount) {
		// TODO Auto-generated method stub
		dao.CreateAccount(bankaccount);
	}

	@Override
	public double displayBalance(int accountNo) {

		// TODO Auto-generated method stub
		BankAccount ba = dao.displayBalance(accountNo);
		try {
			if (ba == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				return ba.getAccountBalance();
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}
		return 0;
	}

	@Override
	public void deposit(int accountNo, double amount) {
		// TODO Auto-generated method stub
		double currBalance = 0;
		BankAccount ba = dao.deposit(accountNo, amount);
		try {
			if (ba == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				dao.displayBalance(accountNo);
				double balance = ba.getAccountBalance();
				currBalance = balance + amount;
				ba.setAccountBalance(currBalance);
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}

	}

	@Override
	public void withdraw(int accountNo, double amount) {
		// TODO Auto-generated method stub
		double currBalance = 0;
		BankAccount ba = dao.deposit(accountNo, amount);
		try {
			if (ba == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				dao.displayBalance(accountNo);
				double balance = ba.getAccountBalance();
				currBalance = balance - amount;
				try {
					if (currBalance < 0) {
						throw new InsufficientBalanceException("balance is less than the withdrawl amount");
					} else
						ba.setAccountBalance(currBalance);
				} catch (InsufficientBalanceException ex) {
					System.err.println(ex.getMessage());
				}
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}

	}

	@Override
	public void fundTransfer(int accountNo1, int accountNo2, double amount) {
		// TODO Auto-generated method stub
		double acc1Balance = 0;
		double acc2Balance = 0;
		int count = 0;
		List<BankAccount> transfer = dao.fundTransfer(accountNo1, accountNo2, amount);
		for (int i = 0; i < transfer.size(); i++) {
			int k = transfer.get(i).getAccountNo();
			if (k == accountNo1 || k == accountNo2) {
				count = count + 1;
			}
		}

		if (count == 2) {
			count = 0;
			for (int i = 0; i < transfer.size(); i++) {
				int k = transfer.get(i).getAccountNo();
				if (k == accountNo1) {
					double balance = transfer.get(i).getAccountBalance();
					acc1Balance = balance - amount;
					try {
						if (acc1Balance < 0) {
							count = 1;
							throw new InsufficientBalanceException("balance is less than the transfer amount");
						} else {
							transfer.get(i).setAccountBalance(acc1Balance);
							// bean.setAccountBalance(acc1Balance);
							dao.update(accountNo1, transfer.get(i));

						}
					} catch (InsufficientBalanceException ex) {
						System.out.println(ex.getMessage());
					}

				} else if (k == accountNo2) {
					if (count == 0) {
						double balance = transfer.get(i).getAccountBalance();
						acc2Balance = balance + amount;
						// bean.setAccountBalance(acc2Balance);
						transfer.get(i).setAccountBalance(acc2Balance);
						dao.update(accountNo2, transfer.get(i));
					}

				}
			}

		} else
			System.err.println("Enter valid account numbers");

	}

	@Override
	public void printTransactions(int accountNo) {
		// TODO Auto-generated method stub
		Transaction trans = dao.printTransactions(accountNo);
		try {
			if (trans == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				System.out.println(trans);
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}

	}
}
