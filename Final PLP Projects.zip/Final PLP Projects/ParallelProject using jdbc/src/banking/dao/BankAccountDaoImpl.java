package banking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



import banking.bean.BankAccount;


public class BankAccountDaoImpl implements BankAccountDao {
	static List<BankAccount> list = new ArrayList<BankAccount>();
	
	static BankAccount account = new BankAccount();
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	@Override
	public BankAccount CreateAccount(BankAccount account) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		try {
			conn = DBUtil.getConnection();
			String sql = "insert into account values(accNo_seq.nextval,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, account.getAccountName());
			pstmt.setLong(2, account.getPhoneNo());
			pstmt.setDouble(3, account.getInitialBalance());
			pstmt.executeUpdate();
			boolean exe = pstmt.execute();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select accNo_seq.currval from dual");
			if (rs.next())
				account.setAccountNo(rs.getInt(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}

	@Override
	public BankAccount displayBalance(int accountNo) throws ClassNotFoundException {
		BankAccount b = new BankAccount();
			try {
				conn = DBUtil.getConnection();
				Statement s = conn.createStatement();
				ResultSet rs = s.executeQuery("select * from account where accountid=" + accountNo);
				while (rs.next()) {
					b.setAccountNo(rs.getInt(1));
					b.setAccountName(rs.getString(2));
					b.setPhoneNo(rs.getLong(3));
					b.setInitialBalance(rs.getDouble(4));
				}
			}
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			//System.out.println(b);
			return b;
		}
	
	@Override
	public BankAccount deposit(int accountNo, double amount) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		BankAccount b = new BankAccount();
		try {
			conn = DBUtil.getConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from account where accountid=" + accountNo);
			while (rs.next()) {
				account.setAccountNo(rs.getInt(1));
				account.setAccountName(rs.getString(2));
				account.setPhoneNo(rs.getLong(3));
				account.setInitialBalance(rs.getDouble(4)+ amount);
			}
			PreparedStatement p = conn.prepareStatement(
					"update account set balance=" + account.getInitialBalance() + " where accountid =" + accountNo);
			p.executeUpdate();

			p = conn.prepareStatement("insert into transaction values(transactionidseq.nextval,?,?,?,?)");
			p.setInt(1, accountNo);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Deposited");
			p.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return account;
	}

	@Override
	public BankAccount withdraw(int accountNo, double amount) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		
		BankAccount b = new BankAccount();
		try {
			conn = DBUtil.getConnection();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from account where accountid=" + accountNo);
			while (rs.next()) {
				account.setAccountNo(rs.getInt(1));
				account.setAccountName(rs.getString(2));
				account.setPhoneNo(rs.getLong(3));
				account.setInitialBalance(rs.getDouble(4)- amount);
			}
			PreparedStatement p = conn.prepareStatement(
					"update account set balance=" + account.getInitialBalance() + " where accountid =" + accountNo);
			p.executeUpdate();

			p = conn.prepareStatement("insert into transaction values(transactionidseq.nextval,?,?,?,?)");
			p.setInt(1, accountNo);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "withdrawl");
			p.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return account;
	}

	@Override
	public BankAccount fundTransfer(int accountNo1, int accountNo2, double amount) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		 BankAccount account1 = new BankAccount();
		 BankAccount b1 = new BankAccount();
			try {
				conn = DBUtil.getConnection();
				Statement s = conn.createStatement();
				ResultSet rs = s.executeQuery("select * from account where accountid=" + accountNo1);
				while (rs.next()) {
					account.setAccountNo(rs.getInt(1));
					account.setAccountName(rs.getString(2));
					account.setPhoneNo(rs.getLong(3));
					account.setInitialBalance(rs.getDouble(4)- amount);
				}
				PreparedStatement p = conn.prepareStatement(
						"update account set balance=" + account.getInitialBalance() + " where accountid =" + accountNo1);
				p.executeUpdate();

				p = conn.prepareStatement("insert into transaction values(transactionidseq.nextval,?,?,?,?)");
				p.setInt(1, accountNo1);
				p.setDate(2, new Date(System.currentTimeMillis()));
				p.setDouble(3, amount);
				p.setString(4, "Deposited");
				p.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
				
				// TODO Auto-generated method stub
			BankAccount b = new BankAccount();
			try {
				conn = DBUtil.getConnection();
				Statement s = conn.createStatement();
				ResultSet rs = s.executeQuery("select * from account where accountid=" + accountNo2);
				while (rs.next()) {
					b.setAccountNo(rs.getInt(1));
					b.setAccountName(rs.getString(2));
					b.setPhoneNo(rs.getLong(3));
					b.setInitialBalance(rs.getDouble(4)+ amount);
				}
				PreparedStatement p = conn.prepareStatement(
						"update account set balance=" + b.getInitialBalance() + " where accountid =" + accountNo2);
				p.executeUpdate();

				p = conn.prepareStatement("insert into transaction values(transactionidseq.nextval,?,?,?,?)");
				p.setInt(1, accountNo2);
				p.setDate(2, new Date(System.currentTimeMillis()));
				p.setDouble(3, amount);
				p.setString(4, "withdrawl");
				p.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return account;
		
	}

	@Override
	public ArrayList printDetails(int account_id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ArrayList<String> a = new ArrayList<String>();
		conn = DBUtil.getConnection();
		String str = "";
		try {
			
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Trans_info where account_id=" + account_id);
			while (rs.next()) {
				str = String.valueOf(rs.getInt(1))+"\t\t";
				str+=rs.getInt(2)+"\t\t";
				str+=rs.getDate(3)+"\t\t";
				str+=rs.getDouble(4)+"\t\t";
				str+=rs.getString(5);
				a.add(str);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
	}

	
	
}


